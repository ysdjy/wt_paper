"""Adapter for the Mendeley / LUH-IFW dataset

    "Multivariate time series data of milling processes with varying tool wear
     and machine tools"   (Denkena, Klemme, Stiehl; DOI 10.17632/zpxs87bjt8.3)

6418 run-level HDF5 files, 3 machines x 3 tools.  Filenames encode
M{machine}T{tool}R{run}C{cumulated_contact_time}VB{wear}.h5 and `filelist.csv`
carries the same labels (verified identical for all 6418 rows).

SEMANTICS
---------
    sequence_id = Tool   (T1..T9)  -- one independent degradation sequence,
                                      q is normalised inside it
    domain_id   = Machine(M1..M3)  -- the transfer domain

KNOWN DATA ISSUES (from the dataset documentation).  These drive the
primary/restricted channel split; they are never silently ignored.
    M2 (T4,T5,T6): aliasing on the feed-drive force and spindle torque
    M3 (T7,T8)   : machine/workpiece coordinate mismatch affecting position,
                   position control deviation and feed-drive force
    T8           : runs from the initial wear phase are absent -- the first
                   available run is already at VB = 34 um
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .base import DatasetAdapter, Task
from ..features import channel_features

FNAME_RE = re.compile(r"^M(\d+)T(\d+)R(\d+)C(\d+)VB(\d+)\.h5$")

# --- channel registry -------------------------------------------------------
# nominal sampling rates come from the dataset publication; verified against
# the file attributes at scan time when available.
GROUP_FS = {"signals_sensor": 25000.0, "signals_machine": 500.0}
TIME_CHANNELS = {"time_sensor", "time_machine"}

# ---------------------------------------------------------------------------
# Documented artefacts, mapped to channels ONLY where the channel name matches
# the documentation exactly. Where the documentation names a channel that does
# not exist in the files, the candidate is marked UNRESOLVED rather than
# guessed. Nothing here is inferred from a name resembling another name.
#
# Documentation states:
#   M2 (T4,T5,T6): aliasing on  "force_axis"  and  "torque_spindle"
#   M3 (T7,T8)   : machine/workpiece coordinate mismatch affecting
#                  "position_axis", "position_control_deviation_axis",
#                  "force_axis"
# ---------------------------------------------------------------------------
CONFIRMED_ISSUES = {
    # exact name match with the documentation
    "torque_spindle": dict(issue="aliasing", scope=["T4", "T5", "T6"],
                           evidence="channel name matches the documented 'torque_spindle' exactly"),
}
# Prefix match against a documented name, applied only when the file actually
# contains a channel whose name starts with the documented token.
CONFIRMED_PREFIX_ISSUES = {
    "position_control_deviation_axis": dict(
        issue="machine/workpiece coordinate mismatch", scope=["T7", "T8"],
        evidence="channel name matches the documented 'position_control_deviation_axis'"),
}
# Documented names with NO corresponding channel in the files. Any channel that
# a human might be tempted to map onto them is listed as a candidate, but the
# status stays UNRESOLVED until confirmed against the data or the authors.
UNRESOLVED_DOC_NAMES = {
    "force_axis": dict(
        documented_scope_aliasing=["T4", "T5", "T6"],
        documented_scope_coordinate=["T7", "T8"],
        candidates_in_file=["torque_axis_x", "torque_axis_y", "torque_axis_z"],
        note=("No channel named 'force_axis' exists. torque_axis_* is a feed-drive "
              "quantity and is the only plausible candidate, but force != torque and "
              "this has NOT been confirmed. Do not map it silently.")),
    "position_axis": dict(
        documented_scope_coordinate=["T7", "T8"],
        candidates_in_file=["tool_position_x", "tool_position_y", "tool_position_z"],
        note=("No channel named 'position_axis' exists. tool_position_* is the only "
              "plausible candidate. NOT confirmed.")),
}
UNRESOLVED_CHANNELS = sorted({c for v in UNRESOLVED_DOC_NAMES.values()
                              for c in v["candidates_in_file"]})


def channel_status(ch: str) -> tuple[str, dict]:
    """-> ('primary' | 'restricted' | 'unresolved', evidence dict)"""
    if ch in CONFIRMED_ISSUES:
        return "restricted", CONFIRMED_ISSUES[ch]
    for pref, meta in CONFIRMED_PREFIX_ISSUES.items():
        if ch.startswith(pref):
            return "restricted", meta
    if ch in UNRESOLVED_CHANNELS:
        which = [k for k, v in UNRESOLVED_DOC_NAMES.items() if ch in v["candidates_in_file"]]
        return "unresolved", dict(issue="UNRESOLVED", scope=[],
                                  evidence=f"possible match for documented name(s) {which}; not confirmed")
    return "primary", dict(issue="", scope=[], evidence="no documented artefact matches this channel name")


class MendeleyMachineToolWear(DatasetAdapter):
    name = "mendeley_machine_tool_wear"

    def __init__(self, raw_dir: str | Path, out_dir: str | Path,
                 channel_set: str = "primary", n_bands: int = 5):
        self.raw_dir = Path(raw_dir)
        self.out_dir = Path(out_dir)
        self.channel_set = channel_set     # "primary" | "all"
        self.n_bands = n_bands
        self.measured_fs: dict[str, float] = {}
        self.out_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ meta
    def read_filelist(self) -> pd.DataFrame:
        fl = self.raw_dir / "filelist.csv"
        if not fl.exists():
            raise FileNotFoundError(fl)
        df = pd.read_csv(fl)
        df.columns = [c.strip() for c in df.columns]
        df = df.rename(columns={"cumulated_tool_contact_time": "ctime", "wear": "VB"})
        p = df["filename"].str.extract(FNAME_RE).astype(float)
        p.columns = ["m", "t", "r", "c", "vb"]
        bad = ((p["m"] != df["machine"]) | (p["t"] != df["tool"]) |
               (p["r"] != df["run"]) | (p["c"] != df["ctime"]) | (p["vb"] != df["VB"]))
        if bad.any():
            raise ValueError(f"{int(bad.sum())} rows where filename and filelist.csv disagree")
        df["domain_id"] = "M" + df["machine"].astype(int).astype(str)
        df["sequence_id"] = "T" + df["tool"].astype(int).astype(str)
        df["order_key"] = df["run"].astype(int)
        df["source_file"] = df["filename"]
        return df[["sequence_id", "domain_id", "order_key", "VB", "ctime",
                   "source_file"]].sort_values(["sequence_id", "order_key"]).reset_index(drop=True)

    # --------------------------------------------------------------- schema
    def scan_schema(self, probe_files: list[str] | None = None) -> dict:
        """Open a few files and record the true HDF5 tree. Requires h5py."""
        import h5py
        meta = self.read_filelist()
        if probe_files is None:
            probe_files = []
            for tool in ["T1", "T4", "T7", "T8", "T9"]:
                sub = meta[meta.sequence_id == tool]
                if len(sub):
                    for frac in (0.0, 0.5, 0.95):
                        probe_files.append(sub.iloc[int(frac * (len(sub) - 1))]["source_file"])
        report: dict = {"dataset": self.name, "files": {},
                        "unresolved_documented_names": UNRESOLVED_DOC_NAMES}
        for fn in probe_files:
            path = self.raw_dir / fn
            entry: dict = {"root_attrs": {}, "datasets": {}}
            with h5py.File(path, "r") as h:
                entry["root_attrs"] = {k: _jsonable(v) for k, v in h.attrs.items()}

                def visit(name, obj):
                    if isinstance(obj, h5py.Dataset):
                        entry["datasets"][name] = dict(
                            shape=list(obj.shape), dtype=str(obj.dtype),
                            compression=obj.compression,
                            attrs={k: _jsonable(v) for k, v in obj.attrs.items()})
                h.visititems(visit)
            entry["fs_measured"] = _measure_fs(path, entry["datasets"])
            report["files"][fn] = entry
        report["channels"] = sorted({n.split("/")[-1]
                                     for e in report["files"].values()
                                     for n in e["datasets"]})
        return report

    def discover_channels(self) -> dict[str, list[str]]:
        """Channels present in EVERY probed file, grouped, time axes removed."""
        rep = self.scan_schema()
        per_file = []
        for e in rep["files"].values():
            per_file.append({n for n in e["datasets"]})
        common = set.intersection(*per_file) if per_file else set()
        groups: dict[str, list[str]] = {}
        for full in sorted(common):
            grp, _, leaf = full.rpartition("/")
            if leaf in TIME_CHANNELS:
                continue
            groups.setdefault(grp or "/", []).append(leaf)
        return groups

    def primary_channel_set(self, groups: dict[str, list[str]]) -> dict:
        """Channels with no documented artefact AND no unresolved mapping."""
        buckets = {"primary": {}, "restricted": {}, "unresolved": {}}
        for grp, chans in groups.items():
            for ch in chans:
                st, _ = channel_status(ch)
                buckets[st].setdefault(grp, []).append(ch)
        return {**buckets,
                "policy": ("Version A (primary) is used for the main experiments. "
                           "Restricted channels have a documented artefact. "
                           "UNRESOLVED channels are documented-name candidates that "
                           "could NOT be confirmed against the files; they are kept "
                           "out of the primary set and out of any silent mapping."),
                "unresolved_documented_names": UNRESOLVED_DOC_NAMES}

    def excluded_channel_report(self, groups: dict[str, list[str]]) -> pd.DataFrame:
        rows = []
        for grp, chans in groups.items():
            for ch in chans:
                st, meta = channel_status(ch)
                scope = meta.get("scope") or []
                rows.append(dict(channel=ch, group=grp, status=st,
                                 tools_affected=",".join(scope),
                                 machines_affected=",".join(sorted({_tool2machine(t) for t in scope})),
                                 reason=meta.get("issue", ""),
                                 evidence=meta.get("evidence", ""),
                                 used_in_primary_experiment=(st == "primary"),
                                 retained_in_raw_data=True))
        return pd.DataFrame(rows).sort_values(["status", "group", "channel"]).reset_index(drop=True)

    def channel_summary(self, report: dict) -> pd.DataFrame:
        """One row per (file, dataset) from the REAL h5 scan -- shape, dtype,
        compression, attrs, and the fs actually implied by the time channel."""
        rows = []
        for fn, e in report["files"].items():
            for name, meta in e["datasets"].items():
                grp, _, leaf = name.rpartition("/")
                st, ev = channel_status(leaf)
                rows.append(dict(file=fn, group=grp or "/", channel=leaf, path=name,
                                 shape="x".join(map(str, meta["shape"])),
                                 n_samples=meta["shape"][0] if meta["shape"] else 0,
                                 dtype=meta["dtype"], compression=meta.get("compression"),
                                 attrs=json.dumps(meta.get("attrs", {}), ensure_ascii=False),
                                 fs_measured_hz=e.get("fs_measured", {}).get(grp or "/"),
                                 status=st, status_evidence=ev.get("evidence", "")))
        return pd.DataFrame(rows)

    # ------------------------------------------------------- feature build
    def channels_for(self, groups: dict[str, list[str]]) -> list[tuple[str, str, float]]:
        sel = self.primary_channel_set(groups)
        use = sel["primary"] if self.channel_set == "primary" else groups
        out = []
        for grp, chans in use.items():
            fs = self.measured_fs.get(grp, GROUP_FS.get(grp.strip("/"), np.nan))
            for ch in chans:
                out.append((grp, ch, fs))
        return sorted(out, key=lambda t: (t[0], t[1]))

    def extract_features(self, channels, files: pd.DataFrame,
                         progress=None) -> pd.DataFrame:
        """Feature rows for the given subset of files. Requires h5py."""
        import h5py
        rows = []
        for i, r in enumerate(files.itertuples(index=False)):
            path = self.raw_dir / r.source_file
            row = dict(sequence_id=r.sequence_id, domain_id=r.domain_id,
                       order_key=int(r.order_key), VB=float(r.VB),
                       ctime=float(r.ctime), source_file=r.source_file)
            try:
                with h5py.File(path, "r") as h:
                    for grp, ch, fs in channels:
                        key = f"{grp}/{ch}" if grp not in ("", "/") else ch
                        if key not in h:
                            row.update({k: np.nan for k in
                                        channel_features(np.array([]), fs, ch, self.n_bands)})
                            continue
                        x = np.asarray(h[key][()], dtype=np.float64).ravel()
                        row.update(channel_features(x, fs, ch, self.n_bands))
                row["_read_error"] = ""
            except Exception as exc:                       # noqa: BLE001
                row["_read_error"] = f"{type(exc).__name__}: {exc}"
            rows.append(row)
            if progress and (i + 1) % 50 == 0:
                progress(i + 1, len(files))
        return pd.DataFrame(rows)

    def load_run_level_table(self) -> pd.DataFrame:
        f = self.out_dir / f"run_level_features_{self.channel_set}.csv"
        if not f.exists():
            raise FileNotFoundError(
                f"{f} not found -- run scripts/00_extract_features.py first")
        df = pd.read_csv(f)
        self.validate_table(df)
        return df

    # ------------------------------------------------------------- protocol
    def task_definitions(self) -> list[Task]:
        M = {"M1": ["T1", "T2", "T3"], "M2": ["T4", "T5", "T6"], "M3": ["T7", "T8", "T9"]}
        tasks: list[Task] = []
        # Group A -- leave-one-machine-out, dual source
        for i, (name, held) in enumerate([("D1-M", "M3"), ("D2-M", "M2"), ("D3-M", "M1")], 1):
            tr = [m for m in M if m != held]
            tasks.append(Task(name=name, group="cross_machine_dual",
                              train_domains=tr, test_domains=[held],
                              train_sequences=[t for m in tr for t in M[m]],
                              test_sequences=M[held],
                              notes=f"{'+'.join(tr)} -> {held}"))
        # Group B -- single source, all six directions
        k = 0
        for src in ["M1", "M2", "M3"]:
            for dst in ["M1", "M2", "M3"]:
                if src == dst:
                    continue
                k += 1
                tasks.append(Task(name=f"MS{k}", group="cross_machine_single",
                                  train_domains=[src], test_domains=[dst],
                                  train_sequences=M[src], test_sequences=M[dst],
                                  notes=f"{src} -> {dst}"))
        # Group C -- leave-one-tool-out
        all_tools = [t for m in M for t in M[m]]
        for t in all_tools:
            home = _tool2machine(t)
            tasks.append(Task(
                name=f"LOTO_{t}", group="leave_one_tool_out",
                train_domains=list(M), test_domains=[home],
                train_sequences=[x for x in all_tools if x != t], test_sequences=[t],
                notes=(f"held-out tool {t} (machine {home}); same-machine tools in "
                       f"train: {[x for x in M[home] if x != t]}"
                       + ("; WARNING early stage truncated (first run already at VB=34um)"
                          if t == "T8" else ""))))
        for t in tasks:
            t.validate()
        return tasks


def _tool2machine(t: str) -> str:
    n = int(t[1:])
    return f"M{(n - 1) // 3 + 1}"


def _jsonable(v):
    if isinstance(v, (bytes, np.bytes_)):
        return v.decode("utf-8", "replace")
    if isinstance(v, np.generic):
        return v.item()
    if isinstance(v, np.ndarray):
        return [_jsonable(x) for x in v.tolist()]
    return v


def _measure_fs(path, datasets: dict) -> dict:
    """Sampling rate measured from the time channel actually stored in the file."""
    import h5py
    out = {}
    with h5py.File(path, "r") as h:
        for name in datasets:
            grp, _, leaf = name.rpartition("/")
            if leaf not in TIME_CHANNELS:
                continue
            try:
                t = np.asarray(h[name][()], dtype=np.float64).ravel()
                if t.size > 2:
                    dt = float(np.median(np.diff(t)))
                    out[grp or "/"] = round(1.0 / dt, 4) if dt > 0 else None
            except Exception:                                     # noqa: BLE001
                out[grp or "/"] = None
    return out
